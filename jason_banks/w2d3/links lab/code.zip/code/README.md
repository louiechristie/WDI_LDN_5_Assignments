## Links Demo (3:45 - 4:30)

**Objectives:**

* Create a multi-page app with Sinatra
* Create a layout.erb template
* Implement basic routing

**Activity:**

* Walk students through creating a multi-page app with Sinatra